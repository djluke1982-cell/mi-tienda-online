# Tienda Cloudinary para Render (gratis)
Sigue las instrucciones del README anterior para desplegar en Render.